# Leaderboard database administration

This package holds the initial setup and verification tools for the Neon `dallasai_club` database. Extract it locally only when administering the database. The website runs with Hugo; the live API is maintained in the repository's `backend/` folder. No credentials are included here.

The `leaderboard` schema stores players and each player's best score per game and Central Time day. Supported games are `explore`, `ride` and `snake`; scores range from 1 to 1,000,000. Ties use the earlier timestamp. Blocked players are excluded. Public results contain only nickname, score, game, date and savedAt.

The `dallasai_leaderboard_api` role executes the scoring and listing functions without direct table access or role administration. The repository's `backend/002_request_limits.sql` adds persistent request quotas and its restricted function. Both migrations have already been applied. Neon Auth is separate and unchanged.

Use Node.js 22.13+ and PostgreSQL 18+ `psql`. From the extracted folder:

```sh
node database/manage.mjs inspect
node database/manage.mjs verify
```

`inspect` reads metadata; `verify` checks permissions and scoring in transactions that are rolled back. `apply` performs the initial setup and checks migration 001's checksum on an existing setup. It does not apply migration 002. Preserve applied migrations unchanged and use a new migration for later schema changes.

The runner loads private connection files from `%LOCALAPPDATA%\dallasai-club-website\`, outside Git and OneDrive:

- `secrets.env`: original administrative connection.
- `secrets.env.database-admin`: administration of `dallasai_club`.
- `secrets.env.worker`: restricted database connection; the filename is retained for this administration runner.

Each file contains `DATABASE_URL`. The runner passes credentials privately to psql and requires TLS and channel binding. These files are private plaintext, not encrypted backups. Vercel uses the restricted connection and a separate `SESSION_SECRET`, stored as sensitive environment variables; a local copy is in `secrets.env.vercel`.

Public submissions use a server-signed player token, input checks and request quotas. Scores are reported by the browser and are accepted without bot protection. Cloudflare Workers and Turnstile are optional future work. Account owners manage moderation, backups and service usage limits.
